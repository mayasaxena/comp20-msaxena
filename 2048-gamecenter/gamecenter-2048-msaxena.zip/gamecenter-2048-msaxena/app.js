var express = require("express");
var app = express();

app.set('title', '2048 Score Center');
app.use(express.json());       // to support JSON-encoded bodies
app.use(express.urlencoded()); // to support URL-encoded 

// Allow CORS
app.all('/submit.json', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', "Origin, X-Requested-With, Content-Type, Accept");
  next();
 });



// Mongo initialization
// Code taken from Ming's example

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

app.listen(process.env.PORT || 3000);

app.get('/', function(req, res, next) {
        res.set("Content-Type", "text/html");
        var page = "<!DOCTYPE html>\
        <html>\
        <head>\
          <title>2048 Game Center</title>\
          <style>\
            table { \
              width:400px;\
            }\
            td, th {\
              text-align:left;\
              padding:10px;\
              padding-left:5px;\
            }\
          </style>\
        </head>\
        <body>\
        <h1>2048 Score Center</h1>\
        <table>\
        <tr>\
          <th>Timestamp</th>\
          <th>Username</th>\
          <th>Score</th>\
        </tr>";

        db.collection('scores', function(er, collection) {
          collection.find().sort( {score:-1}).limit(100).toArray(function(err, cursor) {
            for(var count = 0; count < cursor.length; count++) {
              page += "<tr><td>" + cursor[count].created_at + "</td><td>" + cursor[count].username + "</td><td>" + cursor[count].score + "</td></tr>";
            }
              page += "</table></body></html>";
              res.send(page);
          })
        
      });


});

app.get('/scores.json', function(req, res, next) {
        res.set('Content-Type', 'text/json');
        var un = req.query.username; // dealing with a query variable
        //lookup username in database
        var scorepage = "[";

        db.collection('scores', function(er, collection) {
          collection.find({"username":un}).sort( {score:-1}).limit(100).toArray(function(err, cursor) {
            for(var count = 0; count < cursor.length; count++) {
              scorepage += JSON.stringify(cursor[count]);
            }
              scorepage += "]"
              res.send(scorepage);
          })
        
      });
});

app.post('/submit.json', function(req, res, next) {
  db.collection('scores', function(error, collection) {
    if (req.body.score != null && req.body.username != null && req.body.grid != null) {
      record = {"score":req.body.score, "username" : req.body.username, "grid" : req.body.grid, "created_at" : req.body.created_at};
        collection.insert(record, function(error, saved) {
        res.send(200);
      });
    }
    else {
      res.send(400);
    }
  });
});



 

